#!/bin/sh

mkdir -p wpscan
cd wpscan
svn checkout http://wpscan.googlecode.com/svn/trunk/ ./wpscan-1.1
